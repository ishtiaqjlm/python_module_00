# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    ft_garden_name.py                                  :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2026/11/14 17:17:13 by ishtiahm          #+#    #+#              #
#    Updated: 2026/11/14 17:26:42 by ishtiahm         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

def ft_garden_name():
    print(">>> ft_garden_name()")
    name = input("Enter garden name: ")
    print("Garden: ", name)
    print("Status: Growing well!")
