#!/usr/bin/env python3
class Plant:
    def __init__(self, name, height, age_in_days):
        self._name = name
        if height < 0:
            print("Error: Height cannot be negative.")
            self._height = 0
        else:
            self._height = height
        if age_in_days < 0:
            print("Error: Age cannot be negative.")
            self._age_in_days = 0
        else:
            self._age_in_days = age_in_days

    def show(self):
        print(f"{self._name}: {self._height:.1f} cm, {self._age_in_days} days old")
    def grow(self):
        self._height += 0.8
    def age(self):
        self._age_in_days += 1

rose = Plant("Rose", 25, 30)
oak = Plant("Oak", 200, 365)
cactus = Plant("Cactus", 5, 90)
sunflower = Plant("Sunflower", 80, 45)
fern = Plant("Fern", 15, 120)
plants = [rose, oak, cactus, sunflower, fern]
print("=== Plant Factory Output ===")

for item in plants:
    print("Created: ", end="")
    item.show()
