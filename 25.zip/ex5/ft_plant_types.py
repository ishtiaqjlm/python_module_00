#!/usr/bin/env python3
class Plant:
    def __init__(self, name, height, age_in_days):
        self._name = name
        self._height = height
        self._age_in_days = age_in_days

    def show(self):
        print(f"{self._name}: {self._height:.1f}cm, "
              f"{self._age_in_days} days old")

    def grow(self, amount=0.8):
        self._height += amount

    def age(self):
        self._age_in_days += 1


class Flower(Plant):
    def __init__(self, name, height, age_in_days, color):
        # Call parent constructor
        super().__init__(name, height, age_in_days)
        # Initialize color
        self._color = color
        self._bloomed = False

    def bloom(self):
        self._bloomed = True

    def show(self):
        super().show()
        print(f"Color: {self._color}")

        if self._bloomed:
            print(f"{self._name} is blooming beautifully!")
        else:
            print(f"{self._name} has not bloomed yet")


class Tree(Plant):
    def __init__(self, name, height, age_in_days, trunk_diameter):
        super().__init__(name, height, age_in_days)
        self._trunk_diameter = trunk_diameter

    def show(self):
        super().show()
        print(f"Trunk diameter: {self._trunk_diameter:.1f}cm")

    def produce_shade(self):
        print(
            f"Tree {self._name} now produces a shade "
            f"of {self._height:.1f}cm long and "
            f"{self._trunk_diameter:.1f}cm wide."
        )


class Vegetable(Plant):
    def __init__(self, name, height, age_in_days, harvest_season):
        super().__init__(name, height, age_in_days)
        self._harvest_season = harvest_season
        self._nutritional_value = 0

    def show(self):
        super().show()
        print(f"Harvest season: {self._harvest_season}")
        print(f"Nutritional value: {round(self._nutritional_value)}")

    def grow(self):
        super().grow(2.1)
        self._nutritional_value += 0.5

    def age(self):
        super().age()
        self._nutritional_value += 0.5


# Create instances and test
print("=== Garden Plant Types ===")
print("=== Flower ===")
rose = Flower("Rose", 15.0, 10, "red")
rose.show()

print("[asking the rose to bloom]")
rose.bloom()
rose.show()

print("=== Tree ===")
oak = Tree("Oak", 200.0, 365, 5.0)
oak.show()

print("[asking the oak to produce shade]")
oak.produce_shade()

print("=== Vegetable ===")
tomato = Vegetable("Tomato", 5.0, 10, "April")
tomato.show()

print("[make tomato grow and age for 20 days]")

for i in range(20):
    tomato.grow()
    tomato.age()

tomato.show()
