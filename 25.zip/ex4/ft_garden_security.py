#!/usr/bin/env python3

class Plant:
    def __init__(self, name, height, age_in_days):
    self._name = name

    if height < 0:
        print("Error: Height cannot be negative.")
        self._height = 0
    else:
        self._height = height

    if age_in_days < 0:
        print("Error: Age cannot be negative.")
        self._age_in_days = 0
    else:
        self._age_in_days = age_in_days

    def set_height(self, height):
        if height < 0:
            print("Error: Height cannot be negative.")
        else:
            self._height = height

    def get_height(self):
        return self._height

    def set_age(self, age):
        if age < 0:
            print("Error: Age cannot be negative.")
        else:
            self._age_in_days = age

    def get_age(self):
        return self._age_in_days

    def show(self):
        print(f"{self._name}: {self._height:.1f} cm, {self._age_in_days} days old")

print("=== Garden Security System ===")

rose = Plant("Rose", 15, 10)
print("Plant created:", end=" ")
rose.show()

rose.set_height(25)
print("Height updated:", rose.get_height())

rose.set_age(30)
print("Age updated:", rose.get_age())

rose.set_height(-5)
print("Height update rejected")

rose.set_age(-10)
print("Age update rejected")

print("Current state:", end=" ")
rose.show()
