#!/usr/bin/env python3
class Plant:
    def __init__(self, name, height, age_in_days):
        self.name = name
        self.height = height
        self.age_in_days = age_in_days

    def show(self):
        print(f"{self.name}: {self.height:.1f} cm, {self.age_in_days} days old")
    def grow(self):
        self.height += 0.8
    def age(self):
        self.age_in_days += 1

rose = Plant("Rose", 25, 30)
initial_height = rose.height
print("=== Garden Plant Growth ===")
for day in range(1, 8):
    rose.grow()
    rose.age()
    print(f"=== Day {day} ===")
    rose.show()
total_growth = round(rose.height - initial_height, 1)
print(f"Growth this week: {total_growth} cm")
