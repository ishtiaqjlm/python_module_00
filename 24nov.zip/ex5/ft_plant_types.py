#!/usr/bin/env python3
class Plant:
    def __init__(self, name, height, age_in_days):
        self._name = name
        self._height = height
        self._age_in_days = age_in_days

    def show(self):
        print(f"Name: {self._name}")
        print(f"Height: {self._height}")
        print(f"Age (days): {self._age_in_days}")

    def grow(self, amount=0.8):
        self._height += amount

    def age(self):
        self._age_in_days += 1

class Flower(Plant):
    def __init__(self, name, height, age_in_days, color):
        # Call parent constructor
        super().__init__(name, height, age_in_days)
        # Initialize color
        self._color = color
        self._bloomed = False

    def bloom(self):
        # Implement blooming
        if not self._bloomed:
            print(f"{self._name} is blooming beautifully!")
            self._bloomed = True

    def show(self):
        super().show()
        print(f"Color: {self._color}")

        if self._bloomed:
            print(f"{self._name} is blooming beautifully!")
        else:
            print(f"{self._name} has not bloomed yet")


class Tree(Plant):
    def __init__(self, name, height, age_in_days, trunk_diameter):
        super().__init__(name, height, age_in_days)
        self._trunk_diameter = trunk_diameter

    def show(self):
        super().show()
        print(f"Trunk Diameter: {self._trunk_diameter}")

    def produce_shade(self):
        print(
            f"Tree {self._name} now produces a shade "
            f"of {self._height:.1f}cm long and "
            f"{self._trunk_diameter:.1f}cm wide."
        )


class Vegetable(Plant):
    def __init__(self, name, height, age_in_days, harvest_season):
        super().__init__(name, height, age_in_days)
        self._harvest_season = harvest_season
        self._nutritional_value = 0

    def show(self):
        super().show()
        print(f"Harvest Season: {self._harvest_season}")
        print(f"Nutritional Value: {self._nutritional_value}")

    def grow(self):
        super().grow(2.1)
        self._nutritional_value += 0.5

    def age(self):
        super().age()
        self._nutritional_value += 0.5

# Create instances and test
