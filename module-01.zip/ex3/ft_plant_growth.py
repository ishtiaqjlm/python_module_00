#!/usr/bin/env python3
class Plant:
    def grow(self):
        self.height += 0.8


